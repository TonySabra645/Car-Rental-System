/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

/**
 *
 * @author ASUS
 */
public class clsCustomer {
   private int ID;
   private String CustomerName;
   private String AdressCustomer;
   private String PhoneCustomer;
   private static int NextCustomrId=100;
 
  
   public clsCustomer(String CustomerName, String AdressCustomer,String PhoneCustomer)
   {
       this.ID=NextCustomrId++;
       this.PhoneCustomer = PhoneCustomer;
       this.AdressCustomer = AdressCustomer;
       this.CustomerName = CustomerName;
   }
   
   
    public int getID() {
        return ID;
    }
    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String CustomerName) {
        this.CustomerName = CustomerName;
    }

    public String getAdressCustomer() {
        return AdressCustomer;
    }

    public void setAdressCustomer(String AdressCustomer) {
        this.AdressCustomer = AdressCustomer;
    }

    public String getPhoneCustomer() {
        return PhoneCustomer;
    }

    public void setPhoneCustomer(String PhoneCustomer) {
        this.PhoneCustomer = PhoneCustomer;
    }



}
