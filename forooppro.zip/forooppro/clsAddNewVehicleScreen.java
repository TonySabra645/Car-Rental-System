/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;
import java.util.Scanner;
public class clsAddNewVehicleScreen extends clsScreen{
       private static Scanner in =new Scanner(System.in);
    
    
    public static void AddNewVehicleScreen()
    {
        _DrawScreenHeader("ِAdd Vehicle Screen : ");
        
        System.out.println("Choose Vehicle Type : ");
        System.out.println("[1] Car");
        System.out.println("[2] Truck");
        System.out.println("[3] MotorCycle");
        int Type=in.nextInt();
        in.nextLine();
        
        System.out.println("Plate Number : ");
        String PlateNumber=in.nextLine();
        
        System.out.println("Brand : ");
        String Brand=in.nextLine();
        
        System.out.println("Model : ");
        String Model=in.nextLine();
        
        System.out.println("Daily Price : ");
        double DailyPrice=in.nextDouble();
        
        boolean Available = true;
        
        Vehicle V=null;
        
        
        if(Type==1)
        {
            in.nextLine();
            
            System.out.println("Fuel type : ");
            String FuelType=in.nextLine();
            
            System.out.println("Seate : ");
            short Seate=in.nextShort();
            
            System.out.println("AC (True/False) : ");
            boolean AC=in.nextBoolean();
            
            System.out.println("Is Electric Car?? :");
            boolean ElectricCar=in.nextBoolean();
            if (ElectricCar==true )
            {
                
         double More = DailyPrice*0.05;
            DailyPrice+=More;
            }
            V = new Car(PlateNumber,Brand,Model,DailyPrice,Available,FuelType,Seate,AC,ElectricCar);
            
        }
        else if(Type==2)
        {
         in.nextLine();
            System.out.println("Weight Capacity : ");
            double WeightCapacity=in.nextDouble();
            
            System.out.println("Refrigerated (true/flase) : ");
            boolean ref=in.nextBoolean();
            
            if (ref==true)
            {
              double More = DailyPrice*0.05;
            DailyPrice+=More;
            
            }
            
            
            V=new Truck(PlateNumber,Brand,Model,DailyPrice,Available,WeightCapacity,ref);
            
        }
       else if(Type==3)
        {
            in.nextLine();
            System.out.println("Engine Size : ");
            int Engine = in.nextInt();
            
            System.out.println("Saide Care (true/false) : ");
            boolean Side=in.nextBoolean();
            if (Side==true)
            {
              double More = DailyPrice*0.02;
            DailyPrice+=More;
            
            }
            
            
            V= new MotorCycle(PlateNumber,Brand,Model,DailyPrice,Available,Engine,Side);
            
        }
          clsVehicleData.Vehicles.add(V);
          clsFindVehicleByPlateNumber.PrintVehicleCard(V);

        
        System.out.println("Vehicle Added Successfully");
}
    
}













