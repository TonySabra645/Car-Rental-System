/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.forooppro;

import java.time.LocalDate;

/**
 *
 * @author ASUS
 */
public class ForOOPPro {

    public static void main(String[] args) {

clsCustomer C1 = new Individual(
        "DL1001",LocalDate.now() ,
        "Ahmad Ali", "Damascus", "0991111111");

clsCustomer C2 = new Individual(
        "DL1002", LocalDate.now(),
        "Sara Khaled", "Homs", "0992222222");

clsCustomer C3 = new Company(
        "CR5001", 10,
        "Tech Company", "Damascus", "0113333333");

clsCustomersData.Customers.add(C1);
clsCustomersData.Customers.add(C2);
clsCustomersData.Customers.add(C3);



Vehicle V1 = new Car        (
        "SY1001", "Toyota", "Corolla",
        40, true,
        "Gasoline", (short)5, true, false);

Vehicle V2 = new Car(
        "SY1002", "Hyundai", "Elantra",
        45, true,
        "Gasoline", (short)5, true, false);

Vehicle V3 = new Car(
        "SY1003", "Tesla", "Model 3",
        80, true,
        "Electric", (short)5, true, true);

Vehicle V4 = new Truck(
        "TR1001", "Mercedes", "Actros",
        150, true,
        12.5, true);

Vehicle V5 = new MotorCycle(
        "MC1001", "Yamaha", "R1",
        35, true,
        1000, false);

clsVehicleData.Vehicles.add(V1);
clsVehicleData.Vehicles.add(V2);
clsVehicleData.Vehicles.add(V3);
clsVehicleData.Vehicles.add(V4);
clsVehicleData.Vehicles.add(V5);



RentalContract R1 = new RentalContract(
        V1, C1,
        java.time.LocalDate.of(2026, 5, 1),
        5, 200);

RentalContract R2 = new RentalContract(
        V2, C2,
        java.time.LocalDate.of(2026, 5, 10),
        3, 135);

RentalContract R3 = new RentalContract(
        V4, C3,
        java.time.LocalDate.of(2026, 5, 15),
        4, 600);










V1.setAvailable(false);
V2.setAvailable(false);
V4.setAvailable(false);

clsRentalData.Countracts.add(R1);
clsRentalData.Countracts.add(R2);
clsRentalData.Countracts.add(R3);



R1.setReturnDate(java.time.LocalDate.of(2026, 5, 6));
R1.setIsFinished(true);
V1.setAvailable(true);

R2.setReturnDate(java.time.LocalDate.of(2026, 5, 13));
R2.setIsFinished(true);
V2.setAvailable(true);

R3.setReturnDate(java.time.LocalDate.of(2026, 5, 19));
R3.setIsFinished(true);
V4.setAvailable(true);


RentalContract R4 = new RentalContract(
        V4, C3,
        java.time.LocalDate.of(2026, 5, 15),
        4, 600);

R3.setIsFinished(false);


clsMainScreen.ShowMainMenueScreen();



    }

}
 




