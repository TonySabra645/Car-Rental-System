/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class clsUpdateCustomerScreen extends clsScreen{
 


    private static void PrintCustomerCard(clsCustomer C)
        {
            System.out.println("\n=======================================\n");
            System.out.println("Name : "+C.getCustomerName());
            System.out.println("ID : "+C.getID());            
            System.out.println("Adress : "+C.getAdressCustomer());
            System.out.println("Phone : "+C.getPhoneCustomer());
            
        }
    public static void ShowUpdateCustomerScreen()
    {
        
        _DrawScreenHeader("Update Customer Screen");
        Scanner in = new Scanner(System.in);

        clsShowAllCustomerScreen.ShowAllCustomerScreen();
        if (clsCustomersData.Customers.isEmpty()) 
        {
            System.out.println("No Customers Available In System To Update.");
            return;
        }

        System.out.println("Enter Customer ID To Update: ");
        int ID = in.nextInt();
        in.nextLine();
        
        for (clsCustomer C : clsCustomersData.Customers)
        {
            if (ID == C.getID())
            { 
                
                System.out.println("\n Current Data ");
                clsFindCustomersByID.FindCustomer(ID); 
          
                System.out.println("\n Enter New Data ");
                System.out.print("Please Enter Name : ");
                String Name = in.nextLine();
                
                System.out.print("Please Enter Address : ");
                String Address = in.nextLine();
               
                System.out.print("Please Enter Phone : ");
                String Phone = in.nextLine();
                
                
                C.setCustomerName(Name);
                C.setAdressCustomer(Address);
                C.setPhoneCustomer(Phone);
                        
                if (C instanceof Company)
                {
                     System.out.print("Enter Commercial Register : ");
                     String CommercialRegister = in.nextLine();
                 
                     System.out.print("Enter Discount Rate : ");
                     double DiscountRate = in.nextDouble();
                     in.nextLine(); 
                     
                     ((Company) C).setCommercialRegister(CommercialRegister);
                     ((Company) C).setDiscountRate(DiscountRate);                    
                }
                else if (C instanceof Individual) 
                {
                     System.out.print("Enter Number Of Driver License : ");
                     String DriverLicense = in.nextLine();
                    
              String Date = "";
        
        while(true)
        {
            System.out.print("Enter Date of Brith (yyyy-MM-dd): ");
            Date = in.nextLine();
            
            if(clsReturnVehicleScreen.IsValidDate(Date)) 
            {
              break;            
            }
            
            System.out.println("Invalid Calendar Date! Please enter a REAL date. Try again.");
        }        
        LocalDate DateOfBrith=LocalDate.parse(Date);

                    
                     ((Individual) C).setDriverLicense(DriverLicense);
                     ((Individual) C).setDateOfBrith(DateOfBrith);
                }
                
                System.out.println("\nCustomer Updated Successfully!");
                
                System.out.println("\n Updated Data ");
                clsFindCustomersByID.FindCustomer(ID);
                return;
            }
        }
        System.out.println("Customer Not Found.");
    }
}

