
package com.mycompany.forooppro;

import java.time.LocalDate;
import java.util.Scanner;
import java.time.temporal.ChronoUnit;

public class clsReturnVehicleScreen extends clsScreen
{
    public static boolean IsValidDate(String dateStr) {
        if (!dateStr.matches("\\d{4}-\\d{2}-\\d{2}")) return false;
        
        String[] parts = dateStr.split("-");
        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        int day = Integer.parseInt(parts[2]);
        
        int[] daysInMonths = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        
        if (month < 1 || month > 12) return false;
        
        if (month == 2 && ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))) {
            daysInMonths[2] = 29;
        }
        
        return day >= 1 && day <= daysInMonths[month];
    }

    public static void PrintInvoice(RentalContract R, double fine, double finalCost)
    {
        _DrawScreenHeader("Final Invoice");
        System.out.println("Contract ID          : " + R.getContractID());
        System.out.println("Delay Days           : " + R.getDelayDay());
        System.out.println("Original Rental Cost : " + R.getTotalCost());
        System.out.println("Fine Amount          : " + fine);
        System.out.println("------------------------------------");
        System.out.println("Total Amount to Pay  : " + finalCost);
        System.out.println("====================================");
        System.out.println("Vehicle Returned Successfully.");
    }
    
    public static void ShowReturnVehicleScreen()
    {
        Scanner in = new Scanner(System.in);
        
        System.out.print("Enter Contract ID: ");
        int ContractID = in.nextInt();
        
        RentalContract R = clsRentalData.FindContract(ContractID);
        
        if(R == null) {
            System.out.println("\nContract Not Found.");
            return;
        }
        if(R.IsFinished()) {
            System.out.println("\nVehicle Already Returned.");
            return;
        }
        
        in.nextLine(); 
        
        String Date = "";
        
        while(true)
        {
            System.out.print("Enter Return Date (yyyy-MM-dd): ");
            Date = in.nextLine();
            
            if(IsValidDate(Date)) 
            {
              break;            
            }
            
            System.out.println("Invalid Calendar Date! Please enter a REAL date. Try again.");
        }

        LocalDate ReturnDate = LocalDate.parse(Date);
        R.setReturnDate(ReturnDate);

        LocalDate ExpectedDate = R.getStartDate().plusDays(R.getRentDay());
        
        System.out.println("Start Date = " + R.getStartDate());
        System.out.println("Rent Day = " + R.getRentDay());
        System.out.println("Expected Date = " + ExpectedDate);
        System.out.println("Return Date = " + ReturnDate);
        
        int DelayDay = (int) ChronoUnit.DAYS.between(ExpectedDate, ReturnDate);
        if(DelayDay < 0) {
            DelayDay = 0;
        }
        R.setDelayDay(DelayDay);
        
        double Fine = R.getTotalCost() * 0.1 * DelayDay;
        double FinalCost = R.getTotalCost() + Fine;
        
        R.setIsFinished(true);
        R.getVehicles().setAvailable(true);
        
        PrintInvoice(R, Fine, FinalCost);
    }
}