/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.time.LocalDate;

/**
 *
 * @author ASUS
 */
public class RentalContract {
   
private int ContractID; 
private Vehicle Vehicle;
private clsCustomer Customer;
private LocalDate StartDate;
private LocalDate ReturnDate;
private double TotalCost;
private boolean IsFinished;
private int RentDay;
private int DelayDay;

private static int NextContractID=1;
    public int getContractID() {
        return ContractID;
    }

    public void setContractID(int ContractID) {
        this.ContractID = ContractID;
    }

    public Vehicle getVehicles() {
        return Vehicle;
    }

    public void setVehicles(Vehicle Vehicles) {
        this.Vehicle = Vehicles;
    }

    public clsCustomer getCustomer() {
        return Customer;
    }

    public void setCustomer(clsCustomer Customer) {
        this.Customer = Customer;
    }

    public LocalDate getStartDate() {
        return StartDate;
    }

    public void setStartDate(LocalDate StartDate) {
        this.StartDate = StartDate;
    }

    public LocalDate getReturnDate() {
        return ReturnDate;
    }

    public void setReturnDate(LocalDate ReturnDate) {
        this.ReturnDate = ReturnDate;
    }

    public double getTotalCost() {
        return TotalCost;
    }

    public void setTotalCost(double TotalCost) {
        this.TotalCost = TotalCost;
    }

    public boolean IsFinished() {
        return IsFinished;
    }

    public void setIsFinished(boolean IsFinished) {
        this.IsFinished = IsFinished;
    }

    public int getRentDay() {
        return RentDay;
    }

    public void setRentDay(int RentDay) {
        this.RentDay = RentDay;
    }

    public int getDelayDay() {
        return DelayDay;
    }

    public void setDelayDay(int DelayDay) {
        this.DelayDay = DelayDay;
    }

    public RentalContract( Vehicle Vehicle, clsCustomer Customer, LocalDate StartDate, int RentDay, double TotalCost) 
    {
        this.ContractID = NextContractID++;
        
        this.Vehicle = Vehicle;
        this.Customer = Customer;
        this.StartDate = StartDate;
        this.ReturnDate = null;
        this.TotalCost = TotalCost;
        this.IsFinished = false;
        this.RentDay = RentDay;
        this.DelayDay = 0;
    }  
    
}
    
    
    
    

