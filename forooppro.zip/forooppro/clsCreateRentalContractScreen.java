
package com.mycompany.forooppro;

import java.time.LocalDate;
import java.util.Scanner;


public class clsCreateRentalContractScreen extends clsScreen
{
    private static double CalculateTotalCost(int RentDay,Vehicle V )
    {
        double TotalCost=0;
        
    if (V instanceof Car)
    {
    TotalCost=(V.getDailyPrice())*RentDay;
    return TotalCost;
    }
     if (V instanceof Truck)
    {
    TotalCost=(V.getDailyPrice())*RentDay;
    return TotalCost;
    }
      if (V instanceof MotorCycle)
    {
    TotalCost=(V.getDailyPrice())*RentDay;
    return TotalCost;
    }
          return TotalCost;

    }
    
    public static void ShowCreateRentalContractScreen (){
        
        _DrawScreenHeader("Create Rental Contract Screen : ");
        
 Scanner in =new Scanner(System.in);
       System.out.println("Please Enter Plate Number : ");
       
       String PlateNumber=in.nextLine();
       Vehicle V =clsFindVehicleByPlateNumber.FindVehicle(PlateNumber);
       if (V==null)
         {
     System.out.println("Vehicle not Found");
          }
        if(V.isAvailable()==false)
        {
            System.out.println("Vehicle is Not Available.");
            return;
        }
          
            System.out.println("Enter ID : ");
            int ID =in.nextInt();
            
            if(clsCustomersData.IsIDExist(ID)==false)
            {
                 System.out.println("Customer Not Found");
                 return;
            }
             
            clsCustomer C= clsFindCustomersByID.FindCustomer(ID);
        
             
            System.out.println("Enter Rent Day: ");
            int RentDay=in.nextInt();
            
            LocalDate today = LocalDate.now();
            
           
            
            
            double TotalCost =CalculateTotalCost(RentDay,V);
            
            if (C instanceof Company)
            {
            TotalCost=TotalCost-(TotalCost*((Company) C).getDiscountRate());
            
            return;
            }
          RentalContract  R= new RentalContract(V,C,today,RentDay,TotalCost);
          clsRentalData.Countracts.add(R);
          
          V.setAvailable(false);
          System.out.println("\n Contract Creatd Successfully");
}
} 
