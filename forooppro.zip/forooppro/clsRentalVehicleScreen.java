/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class clsRentalVehicleScreen extends clsScreen{
    private enum enVehicleRentalOption
    {
        eCreateRentalContract,
        eReturnVehicle,
        eContractsScreen,
        eBack,
    }

    private static short ReadVehicleRentalOption()
    {
        short Option;

        do
        {
            System.out.println("Please Enter Number Between [1 TO 6]");
            Scanner in = new Scanner(System.in);
            Option = in.nextShort();

        } while (Option < 1 || Option > 4);

        return Option;
    }

    private static void GoBackToVehicleRentalMenu()
    {
        System.out.println("Press Enter To Go Back To Vehicle Rental Menu...");
        Scanner in = new Scanner(System.in);
        in.nextLine();

        ShowVehicleRentalScreen();
    }

    private static void ShowCreateRentalContractScreen()
    {
        clsCreateRentalContractScreen.ShowCreateRentalContractScreen();
    }

    private static void ShowReturnVehicleScreen()
    {
        clsReturnVehicleScreen.ShowReturnVehicleScreen();
    }
   private static void ShowContractsScreen()
   {

clsContractsScreen.ShowContractsScreen();

   }
    private static void PerformVehicleRentalOption(
            enVehicleRentalOption Option)
    {

        switch (Option)
        {

            case eCreateRentalContract ->
            {
                ShowCreateRentalContractScreen();
                GoBackToVehicleRentalMenu();
                break;
            }

            case eReturnVehicle ->
            {
                ShowReturnVehicleScreen();
                GoBackToVehicleRentalMenu();
                break;
            }
            case eContractsScreen ->
            {
            
            ShowContractsScreen();
            GoBackToVehicleRentalMenu();
            
            break;
            }
            case eBack ->
            {
                return;
            }
        }

    }

    public static void ShowVehicleRentalScreen()
    {

        _DrawScreenHeader("Vehicle Rental Screen : ");

        System.out.println("[1] Create Rental Contract");
        System.out.println("[2] Return Vehicle");
        System.out.println("[3] Contracts Screen");      
        System.out.println("[4] Back");

        PerformVehicleRentalOption(
                enVehicleRentalOption.values()
                [ReadVehicleRentalOption() - 1]);

    }
}
