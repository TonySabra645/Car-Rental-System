/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

/**
 *
 * @author ASUS
 */
public class Vehicle {
    private String PlateNumber;
    private String Brand;
    private String Model;
    private double DailyPrice;
    private boolean Available;
    
    
   public Vehicle (String PlateNumber,String Brand,String Model,double DailyPrice, boolean Available   )
    {
     this.PlateNumber=PlateNumber;   
     this.Brand=Brand;   
     this.Model=Model;
     this.DailyPrice=DailyPrice;
     this.Available=Available; 
    }

    public String getPlateNumber() {
        return PlateNumber;
    }

    public void setPlateNumber(String PlateNumber) {
        this.PlateNumber = PlateNumber;
    }

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public double getDailyPrice() {
        return DailyPrice;
    }

    public void setDailyPrice(double DailyPrice) {
        this.DailyPrice = DailyPrice;
    }

    public boolean isAvailable() {
        return Available;
    }

    public void setAvailable(boolean Available) {
        this.Available = Available;
    }
}
    

