/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class clsDeleteVehicleScreen extends clsScreen{
    private static Scanner in =new Scanner(System.in);
public static void ShowDeleteVehicleScreen()
{
    _DrawScreenHeader("Delete Vehicle Screen : ");
    
    System.out.println("Please Enter Plate Number : ");
    String PlateNumber=in.nextLine();
    
    
   for(int i = 0; i < clsVehicleData.Vehicles.size(); i++)
    {
        Vehicle V = clsVehicleData.Vehicles.get(i);

        if(V.getPlateNumber().equalsIgnoreCase(PlateNumber))
        {
            clsVehicleData.Vehicles.remove(i);

            System.out.println("Delete Vehicle Successfully.");

            return;
        }
    }

    System.out.println("Vehicle Not Found.");
}
    
    
}
