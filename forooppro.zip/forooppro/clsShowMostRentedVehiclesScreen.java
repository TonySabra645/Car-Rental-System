/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;


public class clsShowMostRentedVehiclesScreen extends clsScreen{

public static void ShowMostRentedVehiclesScreen()
{
    _DrawScreenHeader("Most Retend Vehicle Screen");

if (clsRentalData.Countracts.isEmpty())
{

    System.out.println("Not Contract Found ");
    return ;
}
int MaxRentCount=0;
for (Vehicle V:clsVehicleData.Vehicles)
{
int Count =0;

for (RentalContract R:clsRentalData.Countracts)
{
if (R.getVehicles().getPlateNumber().equalsIgnoreCase(V.getPlateNumber()))
{
Count++;
}
}
if (Count>MaxRentCount)
{
MaxRentCount=Count;
}


}


for (Vehicle V:clsVehicleData.Vehicles)
{
int Count =0;

for (RentalContract R:clsRentalData.Countracts)
{
if (R.getVehicles().getPlateNumber().equalsIgnoreCase(V.getPlateNumber()))
{
Count++;
}

}
if (Count==MaxRentCount && Count >0)
{

System.out.println("\n====================");

        System.out.println("Plate Number : "
                + V.getPlateNumber());

        System.out.println("Brand : "
                + V.getBrand());

        System.out.println("Model : "
                + V.getModel());

        System.out.println("Times Rented : "
                + Count);

        System.out.println("====================");
}

}





}









    
}
