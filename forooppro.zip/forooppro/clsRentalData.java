/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class clsRentalData {
       public static ArrayList<RentalContract> Countracts=new ArrayList<>();
       
  

       

public static RentalContract FindContract(int ContractID)
{
 for (RentalContract R :Countracts )   
 {
if (R.getContractID()==ContractID) 
  {
return R;
  }
 }
 return null;
}

}





