/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class clsReportsAndStatisticsScreen extends clsScreen{
    private enum enReportOption
    {
        eCompanyRevenue,
        eMostRentedVehicles,
        eVIPCustomers,
        eBack
    }

    private static short ReadReportOption()
    {
        Scanner in = new Scanner(System.in);

        short Option;

        do
        {
            System.out.println("Please Enter Number Between [1 TO 4]");
            Option = in.nextShort();

        } while(Option < 1 || Option > 4);

        return Option;
    }

    private static void GoBackToReportMenu()
    {
        System.out.println("Press Enter To Go Back To Report Menu...");
        Scanner in = new Scanner(System.in);
        in.nextLine();

        ShowReportAndStatisticsScreen();
    }

    private static void ShowCompanyRevenueScreen()
    {
        double Revenue = 0;

        for(RentalContract R : clsRentalData.Countracts)
        {    
            if(R.IsFinished())
            {
                Revenue += R.getTotalCost();
            }
        }

        _DrawScreenHeader("Company Revenue");

        System.out.println("Total Revenue : " + Revenue);
    }

    private static void ShowMostRentedVehiclesScreen()
    {
clsShowMostRentedVehiclesScreen.ShowMostRentedVehiclesScreen();
    }

    private static void ShowVIPCustomersScreen()
    {
       clsShowVIPCustomersScreen.ShowVIPCustomersScreen();
    }

    private static void PerformReportOption(enReportOption Option)
    {
        switch(Option)
        {
            case eCompanyRevenue ->
            {
                ShowCompanyRevenueScreen();
                GoBackToReportMenu();
            }

            case eMostRentedVehicles ->
            {
                ShowMostRentedVehiclesScreen();
                GoBackToReportMenu();
            }

            case eVIPCustomers ->
            {
                ShowVIPCustomersScreen();
                GoBackToReportMenu();
            }

            case eBack ->
            {
                return;
            }
        }
    }

    public static void ShowReportAndStatisticsScreen()
    {
        _DrawScreenHeader("Report And Statistics Screen");

        System.out.println("[1] Company Revenue");
        System.out.println("[2] Most Rented Vehicles");
        System.out.println("[3] VIP Customers");
        System.out.println("[4] Back");

        PerformReportOption(
                enReportOption.values()
                [ReadReportOption() - 1]);
    }
}
