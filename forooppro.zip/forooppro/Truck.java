/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

/**
 *
 * @author ASUS
 */
public class Truck extends Vehicle{
    

         private double WeightCapacity;
         private boolean Refrigerated;
         
         
          public Truck(String PlateNumber, String Brand, String Model, double DailyPrice, boolean Available,double WeightCapacity, boolean Refrigerated) {
            super(PlateNumber, Brand, Model, DailyPrice, Available); 
         this.WeightCapacity=WeightCapacity;
         this.Refrigerated=Refrigerated;
             
         
          }

    public double getWeightCapacity() {
        return WeightCapacity;
    }

    public void setWeightCapacity(double WeightCapacity) {
        this.WeightCapacity = WeightCapacity;
    }

    public boolean isRefrigerated() {
        return Refrigerated;
    }

    public void setRefrigerated(boolean Refrigerated) {
        this.Refrigerated = Refrigerated;
    }

}



