/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class clsVehicleScreen extends clsScreen{
      static Scanner in=new Scanner(System.in);
    
    enum enVehicleMenueOption
    {
        eAddNewVehicle,eDeleteVehicle,eFindVehicle,
        eShowAllVehicle,eShowAllAviailableVehicle,eMainMenue
    }
    
 private static short readVehicleMenueOption()
{
              short option;
             do{
             System.out.println("Please Enter Number Between [1 TO 6]");
            
              option=in.nextShort(); 
             }while(option>6||option<1);
           return option;
          
}   
 
 
 private static void GoBackToVehicleMenue()
 {
     System.out.println("Press Enter To Go Back To Vehicle Meune... ");
     
     in.nextLine();
     in.nextLine();
     
     ShowVehicleScreen();
 }
    
 
 private static void ShowAddNewVehicleScreen()
 {
    clsAddNewVehicleScreen.AddNewVehicleScreen();
 }
 
  private static void ShowDeleteVehicleScreen()
 {
    clsDeleteVehicleScreen.ShowDeleteVehicleScreen();
 }
 
  private static void ShowFindVehicleScreen()
 {
     clsFindVehicleByPlateNumber.ShowFindVehicleScreen();
 }
 
  private static void ShowShowAllVehicleScreen()
 {
    clsShowAllVehicleScreen.ShowAllVehicleScreen();
 }
         
  private static void ShowShowAllAviailableVehicleScreen()
 {
    clsShowAllAvailableVehicleScreen.ShowAllAvailableVehicleScreen();
 }
  
  private static void PerformVehicleOption(enVehicleMenueOption VehicleMenueOption)
  {
      switch(VehicleMenueOption)
      {
          case enVehicleMenueOption.eAddNewVehicle ->
          {
              ShowAddNewVehicleScreen();
              GoBackToVehicleMenue();
              break;
          }
          case enVehicleMenueOption.eDeleteVehicle ->
          {
              ShowDeleteVehicleScreen();
              GoBackToVehicleMenue();
              break;
          }
          case enVehicleMenueOption.eFindVehicle ->
          {
              ShowFindVehicleScreen();
              GoBackToVehicleMenue();
              break;
          }
          case enVehicleMenueOption.eShowAllVehicle ->
          {
              ShowShowAllVehicleScreen();
              GoBackToVehicleMenue();
              break;
          }
          case enVehicleMenueOption.eShowAllAviailableVehicle ->
          {
              ShowShowAllAviailableVehicleScreen();
              GoBackToVehicleMenue();
              break;
          }
           case enVehicleMenueOption.eMainMenue ->
           {
               
           }
      }
  }
          
  public static void ShowVehicleScreen() 
          {
              _DrawScreenHeader("Vehicle Screen  : ");
              
    System.out.println("\n[1] Add New Vehicle Screen");
    System.out.println("[2] Delete Vehicle Screen");
    System.out.println("[3] Find Vehicle By Screen");
    System.out.println("[4] All Vehicle Screen");
    System.out.println("[5] All Vehicle Aviailable Screen");
    System.out.println("[6] Main Menue");
    
    PerformVehicleOption(enVehicleMenueOption.values()[readVehicleMenueOption()-1]);
          }
}
