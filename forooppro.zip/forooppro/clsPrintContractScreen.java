/*R.
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class clsPrintContractScreen extends clsScreen{
    private  static void PrintVehicleCard(Vehicle V,clsCustomer C)
 {
     _DrawScreenHeader("The Vehicle Crde is :");
     
        System.out.println("\n=======================================\n");
     System.out.println("Plate Number : "+V.getPlateNumber());
     
     System.out.println("Brand : "+V.getBrand());
     
     System.out.println("Model : "+V.getModel());
     
     System.out.println("Price : "+V.getDailyPrice());
     
     System.out.println("Customer Name :"+C.getCustomerName());     
     
             if(V instanceof Car)
                {              
                    System.out.println("Fuel Type : "+((Car) V).getFuelType());
                    System.out.println("Have Air Condition : "+((Car) V).isHaveAirCondition());
                    System.out.println("Number Of Seates : "+((Car) V).getNumberOfSeats());   
                       System.out.println("\n=======================================\n");
                }
                if(V instanceof Truck)
                {
           
                    System.out.println("Capacity Of Weight : "+((Truck) V).getWeightCapacity());
                    System.out.println("Refrigerated : "+((Truck) V).isRefrigerated());
                      System.out.println("\n=======================================\n");
                }
                if(V instanceof MotorCycle)
                {
               
                    System.out.println("Engine Capacity : "+((MotorCycle) V).EngineCapacity);
                    System.out.println("Having Side Car : "+((MotorCycle) V).HavingSidecar);
                       System.out.println("\n=======================================\n");
                }     

 }
 
 
    static private void PrintContract(RentalContract R)
    {
                 _DrawScreenHeader("The Contract Carde is :");
        
        System.out.println("\n======================================\n");
        System.out.println("Contract ID : "+R.getContractID());
        System.out.println("Coustomr Name : "+R.getCustomer().getCustomerName()+" , His/Her ID : "+R.getCustomer().getID());
        System.out.println(" Coustomr Phone  : "+R.getCustomer().getPhoneCustomer());
        
        System.out.println("Vehicle Brand : "+R.getVehicles().getBrand()+"  ,  Model : "+R.getVehicles().getModel());
        System.out.println("Plate Number : "+R.getVehicles().getPlateNumber());
        System.out.println("Start Rental Date : "+R.getStartDate());
        System.out.println("Rental Period "+R.getRentDay());
        System.out.println("Total Cost Of Vehicle : "+R.getTotalCost());
    }
    public static void ShowActiveContractScreen()
    {
       _DrawScreenHeader(" Active Contract Screen : ");
       
    for(RentalContract R: clsRentalData.Countracts )
    {
        if (!R.IsFinished())
    PrintContract(R);

    }
    
    
 }
     public static void ShowFinishedContractScreen()
     {
                _DrawScreenHeader(" Finished Contract Screen : ");

      for(RentalContract R: clsRentalData.Countracts )
    {
        if (R.IsFinished())
        {
            PrintContract(R);
        System.out.println("Return Date : "+R.getReturnDate());
        System.out.println("Daily Days : "+R.getDelayDay());
        System.out.println("\n======================================\n");
        }
    }
    
     
     }
     public static void ShowAllContractsScreen()
     {
            _DrawScreenHeader(" All Contract Screen : ");
  
            ShowActiveContractScreen();
            ShowFinishedContractScreen();
     }
     public static void ShowContractsByCustomerNameScreen()
     {
         Scanner in =new Scanner (System.in);
                   _DrawScreenHeader("  Contract by name Screen : ");
         System.out.println(" Entre Coustomr  Name :");
        String  CoustomrName =in.nextLine(); 
        
  boolean Found = false;

    for(RentalContract R : clsRentalData.Countracts)
    {
        if(R.getCustomer().getCustomerName()
                .equalsIgnoreCase(CoustomrName))
        {
            Found = true;

            
             PrintContract(R);

        }
    }

    if(!Found)
    {
        System.out.println("No Contracts Found.");
    }
        
     }
     
     
     
    public static void ShowCompanyContractsScreen()
{
    _DrawScreenHeader("Company Contracts Screen : ");

    boolean Found = false;

    for(RentalContract R : clsRentalData.Countracts)
    {
        if(R.getCustomer() instanceof Company)
        {
            PrintContract(R);
            Found = true;
        }
    }

    if(!Found)
    {
        System.out.println("No Company Contracts Found.");
    }
} 
    
    
   public static void ShowRentedVehicleScreen() 
   {
       _DrawScreenHeader(" Rented Vehicle Screen : ");

boolean Found=false ;
for(RentalContract R : clsRentalData.Countracts)
    {
      if(!R.IsFinished())
      {
          Vehicle V=R.getVehicles();
      
          clsFindVehicleByPlateNumber.PrintVehicleCard(V);
          Found =true;
          
    }
   
   }
    if (!Found)
    {
        System.out.println("No Rented Vehicle ");
    }
  }
    
    public static void ShowVehiclesWithFinesScreen()
    {
        _DrawScreenHeader("Vehicles With Fines Screen : ");
    boolean Found=false ;
        for(RentalContract R : clsRentalData.Countracts)
        {
         if (R.getDelayDay()>0)
         {
             Found =true ;
             clsFindVehicleByPlateNumber.PrintVehicleCard(R.getVehicles());
        }
         
         }
        if (!Found )
        {
            System.out.println("No Vehicle With Fines ");
        }
        }
    

public static void ShowRentedVehiclesByPeriodScreen()
{
Scanner in =new Scanner(System.in);
_DrawScreenHeader("Rented Vehicles By Period : ");

if(clsRentalData.Countracts.isEmpty())
{
    System.out.println("No Contracts In System.");
    return;
}

        
        String DateFrom = "";
        
        while(true)
        {
            System.out.print("Enter Date From(yyyy-MM-dd): ");
            DateFrom = in.nextLine();
            
            if(clsReturnVehicleScreen.IsValidDate(DateFrom)) 
            {
              break;            
            }
            
            System.out.println("Invalid Calendar Date! Please enter a REAL date. Try again.");
        }        
       
    
    LocalDate From = LocalDate.parse(DateFrom);

    
    
    
        
        String DateTo = "";
        
        while(true)
        {
            System.out.print("Enter  Date To(yyyy-MM-dd): ");
            DateTo = in.nextLine();
            
            if(clsReturnVehicleScreen.IsValidDate(DateTo)) 
            {
              break;            
            }
            
            System.out.println("Invalid Calendar Date! Please enter a REAL date. Try again.");
        }        
        LocalDate DateOfBrith=LocalDate.parse(DateTo);
    
    
    LocalDate To = LocalDate.parse(DateTo);


    boolean Found = false;
for(RentalContract R : clsRentalData.Countracts)
    {
        LocalDate ContractStart = R.getStartDate();
        LocalDate ContractEnd;


        if(R.getReturnDate() == null)
        {
            ContractEnd = LocalDate.now();
        }
        else
        {
            ContractEnd = R.getReturnDate();
        }


        if(!ContractStart.isAfter(To) 
           && !ContractEnd.isBefore(From))
        {
            Found = true;
PrintVehicleCard(R.getVehicles(),R.getCustomer());
           
        }
    }


    if(!Found)
    {
        System.out.println("No Rented Vehicles In This Period.");
    }
}

public static void ShowRentedMotorCycleByPeriodScreen()
{
Scanner in =new Scanner(System.in);
_DrawScreenHeader("Rented Motor Cycle By Period : ");

if(clsRentalData.Countracts.isEmpty())
{
    System.out.println("No Contracts In System.");
    return;
}


        
        String DateFrom = "";
        
        while(true)
        {
            System.out.print("Enter  Date From(yyyy-MM-dd): ");
            DateFrom = in.nextLine();
            
            if(clsReturnVehicleScreen.IsValidDate(DateFrom)) 
            {
              break;            
            }
            
            System.out.println("Invalid Calendar Date! Please enter a REAL date. Try again.");
        }        
       
    
    LocalDate From = LocalDate.parse(DateFrom);

    
    
    
        
        String DateTo = "";
        
        while(true)
        {
            System.out.print("Enter Date To(yyyy-MM-dd): ");
            DateTo = in.nextLine();
            
            if(clsReturnVehicleScreen.IsValidDate(DateTo)) 
            {
              break;            
            }
            
            System.out.println("Invalid Calendar Date! Please enter a REAL date. Try again.");
        }        
        LocalDate DateOfBrith=LocalDate.parse(DateTo);
    
    
    LocalDate To = LocalDate.parse(DateTo);

    boolean Found = false;
for(RentalContract R : clsRentalData.Countracts)
    {
        LocalDate ContractStart = R.getStartDate();
        LocalDate ContractEnd;


        if(R.getReturnDate() == null)
        {
            ContractEnd = LocalDate.now();
        }
        else
        {
            ContractEnd = R.getReturnDate();
        }


        if(!ContractStart.isAfter(To) 
           && !ContractEnd.isBefore(From))
        {
            if (R.getVehicles() instanceof MotorCycle)
            {
                Found = true;

         PrintVehicleCard(R.getVehicles(),R.getCustomer());
            }
            }
    }


    if(!Found)
    {
        System.out.println("No Rented Motor Cycle In This Period.");
    }








}

public static void ShowCustomersByVehicleScreen()
{
    Scanner in = new Scanner(System.in);

    _DrawScreenHeader("Customers By Vehicle Screen : ");

    System.out.println("Enter Plate Number : ");
    String PlateNumber = in.nextLine();

    boolean Found = false;

    for(RentalContract R : clsRentalData.Countracts)
    {
        if(R.getVehicles().getPlateNumber()
                .equalsIgnoreCase(PlateNumber))
        {
            Found = true;

            System.out.println("\n================================");

            System.out.println("Customer Name : "
                    + R.getCustomer().getCustomerName());

            System.out.println("Customer ID : "
                    + R.getCustomer().getID());

            System.out.println("Customer Phone : "
                    + R.getCustomer().getPhoneCustomer());

            System.out.println("================================");
        }
    }

    if(!Found)
    {
        System.out.println("No Customers Found.");
    }
}










}


