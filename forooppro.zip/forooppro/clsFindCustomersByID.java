
package com.mycompany.forooppro;

import java.util.Scanner;


public class clsFindCustomersByID extends clsScreen{

  private static Scanner in =new Scanner(System.in);
        
        private static void PrintCustomerCard(clsCustomer C)
        {
                         System.out.println("\n=======================================\n");

            System.out.println("Name : "+C.getCustomerName());
            System.out.println("ID : "+C.getID());            
            System.out.println("Adress : "+C.getAdressCustomer());
            System.out.println("Phone : "+C.getPhoneCustomer());
            if(C instanceof Company)
                 {
                     
                       System.out.println("Commercial Register : "+((Company) C).getCommercialRegister());
                       System.out.println("Discount Rate : "+((Company) C).getDiscountRate());
                     System.out.println("\n=======================================\n");

                }
                  if(C instanceof Individual)
                  {
                  
                 
                      System.out.println("Number Of Driver License : "+((Individual) C).getDriverLicense());
                      System.out.println("Date Of Brith : "+((Individual) C).getDateOfBrith());
                         System.out.println("\n=======================================\n");

                  }
                                

        }
        
        public static clsCustomer FindCustomer(int ID)
        {
            
            
            for(clsCustomer C : clsCustomersData.Customers)
            {
        
            if(ID==C.getID())
        {
                PrintCustomerCard(C);
                return C;
        
                }
        
        }
            System.out.println("Customer Not Found.");
            return null;
        }
        public static void ShowFindCustomerScreen()
        {
            _DrawScreenHeader("Find Customer Screen : ");
            System.out.println("Enter ID : ");
            int ID =in.nextInt();
            
     clsCustomer C = FindCustomer(ID);                    }
       }

    

