/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class clsAddNewCustomer extends clsScreen{
  private static Scanner in =new Scanner(System.in);
        
        private static void PrintCustomerCard(clsCustomer C)
        {
            System.out.println("\n=======================================\n");
            System.out.println("Name : "+C.getCustomerName());
            System.out.println("ID : "+C.getID());            
            System.out.println("Adress : "+C.getAdressCustomer());
            System.out.println("Phone : "+C.getPhoneCustomer());
        

            if(C instanceof Company){
                      System.out.println("Commercial Register : "+((Company) C).getCommercialRegister());
                     System.out.println("Discount Rate : "+((Company) C).getDiscountRate());
                     System.out.println("\n=======================================\n");

                }
                  if(C instanceof Individual)
                  {
                  
                 
                      System.out.println("Number Of Driver License : "+((Individual) C).getDriverLicense());
                      System.out.println("Date Of Brith : "+((Individual) C).getDateOfBrith());
                         System.out.println("\n=======================================\n");

                  }
                      
        }
            public static void AddNewCustomerScreen()
            {
                _DrawScreenHeader("Add New Custmor Screen :");
                
                System.out.println("Choose Customer Type : ");
                System.out.println("[1] Customer Company");
                System.out.println("[2] Customer Individual");
                short Choice=in.nextShort();
                in.nextLine();
                System.out.println("Enter Name : ");
                String CustomerName = in.nextLine();
                
                
              
                System.out.println("Enter Adress : ");
                String AdressCustomer = in.nextLine();
                
                
                System.out.println("Enter Phone : ");
                String PhoneCustomer = in.nextLine();
                
                clsCustomer C=null;
                   if(Choice==1)
                 {
                     System.out.println("Enter Commercial Register : ");
                     String CommercialRegister=in.nextLine();
             
                     System.out.println("Enter Discount Rate : ");
                     double DiscountRate=in.nextDouble();
             
                
                  C = new Company(CommercialRegister,DiscountRate,CustomerName,AdressCustomer,PhoneCustomer);
           
                  }                      
                if(Choice==2)
                {
                System.out.println("Enter Number Of Driver License : ");
                String DriverLicense=in.nextLine();
                
                 
        
        String Date = "";
        
        while(true)
        {
            System.out.print("Enter Date of Brith (yyyy-MM-dd): ");
            Date = in.nextLine();
            
            if(clsReturnVehicleScreen.IsValidDate(Date)) 
            {
              break;            
            }
            
            System.out.println("Invalid Calendar Date! Please enter a REAL date. Try again.");
        }        
        LocalDate DateOfBrith=LocalDate.parse(Date);

                    C = new Individual(DriverLicense,DateOfBrith,CustomerName,AdressCustomer,PhoneCustomer);
                }
                
                clsCustomersData.Customers.add(C);
                PrintCustomerCard(C);
                      
                       System.out.println("Customer Added Successfully");
                       
            }

}
    
    
    
    
    
    
    



