/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.Scanner;


public class clsMainScreen extends clsScreen{
     private enum enMainMenueOption
 {
   eCustomerRegistration,
      eVehicleMenue,eVehicleRentale,eReportAndStatistics,eExit;
  
 }   
 
 private static short readMainMenueOption()
{
              short option;
             do{
             System.out.println("Please Enter Number Between [1 TO 5]");
             Scanner in=new Scanner(System.in);
              option=in.nextShort(); 
             }while(option>5||option<1);
           return option;
          
}

 private static void GoBackToMainMenue()
 {
     System.out.println("Press Enter To Go Back To Main Munue... ");
     Scanner in=new Scanner(System.in);
     in.nextLine();
     ShowMainMenueScreen();
 }


private static void ShowCustomerRegistrationScreen()
{
   clsCustomerRegistrationScreen.ShowCustomerRegistarationScreen();
}
private static void ShowVehicleMenueScreen() {
        clsVehicleScreen.ShowVehicleScreen();
    }


private static void ShowVehicleRentalScreen()
{
 clsRentalVehicleScreen.ShowVehicleRentalScreen();
}

private static void ShowReportAndStatisticsScreen()
{
            clsReportsAndStatisticsScreen
            .ShowReportAndStatisticsScreen();
}


private static void PerformMainMenueOption(enMainMenueOption MainMenueOption)
{
    switch(MainMenueOption)
    {
        case enMainMenueOption.eCustomerRegistration ->         {
            ShowCustomerRegistrationScreen();
            GoBackToMainMenue();
            break;
        }
        case enMainMenueOption.eVehicleMenue ->         {
            ShowVehicleMenueScreen();
            GoBackToMainMenue();
            break;
        }
         case enMainMenueOption.eVehicleRentale ->         {
            ShowVehicleRentalScreen();
            GoBackToMainMenue();
            break;
        }
         case enMainMenueOption.eReportAndStatistics->
         {
          ShowReportAndStatisticsScreen();
          GoBackToMainMenue();
          break;
         }
                 
       case enMainMenueOption.eExit ->
       {
           return;
       }

    }
}

public static void ShowMainMenueScreen()
{
    _DrawScreenHeader("Main Screen Project :");
    
    System.out.println("\n[1] Customer Registration Screen");
    System.out.println("[2] Vehicle Menue Screen");
    System.out.println("[3] Vehicle Rental Screen");
    System.out.println("[4] ShowReport And Statistics Screen");
    System.out.println("[5] Exit");
PerformMainMenueOption(enMainMenueOption.values()[readMainMenueOption()-1]);
}

}

