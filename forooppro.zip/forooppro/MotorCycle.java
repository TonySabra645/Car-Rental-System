/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

/**
 *
 * @author ASUS
 */
public class MotorCycle extends Vehicle{
     int EngineCapacity;
    boolean HavingSidecar;
    

    public MotorCycle( String PlateNumber, String Brand, String Model
            , double DailyPrice, boolean Available,int EngineCapacity, Boolean HavingSidecar) {
        super(PlateNumber, Brand, Model, DailyPrice, Available);
        this.EngineCapacity = EngineCapacity;
        this.HavingSidecar = HavingSidecar;
    }

    
    
    
    public int getEngineCapacity() {
        return EngineCapacity;
    }

    public void setEngineCapacity(int EngineCapacity) {
        this.EngineCapacity = EngineCapacity;
    }

    public Boolean getHavingSidecar() {
        return HavingSidecar;
    }

    public void setHavingSidecar(Boolean HavingSidecar) {
        this.HavingSidecar = HavingSidecar;
    }
}
