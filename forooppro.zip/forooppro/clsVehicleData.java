/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class clsVehicleData {
    public static ArrayList<Vehicle> Vehicles=new ArrayList<>();    

static void Remove(Vehicle V)
{
    Vehicles.remove(V);
}
}
