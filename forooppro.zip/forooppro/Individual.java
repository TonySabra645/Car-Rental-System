/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.time.LocalDate;

/**
 *
 * @author ASUS
 */
public class Individual  extends clsCustomer{
     private String  DriverLicense;
    private LocalDate DateOfBrith;
 

   
    public Individual(String DriverLicense, LocalDate DateOfBrith , String CustomerName, String AdressCustomer, String PhoneCustomer) {
        super( CustomerName, AdressCustomer, PhoneCustomer);
        this.DriverLicense = DriverLicense;
        this.DateOfBrith = DateOfBrith;
    
    }

    public String getDriverLicense() {
        return DriverLicense;
    }

    public void setDriverLicense(String DriverLicense) {
        this.DriverLicense = DriverLicense;
    }

    public LocalDate getDateOfBrith() {
        return DateOfBrith;
    }

    public void setDateOfBrith(LocalDate DateOfBrith) {
        this.DateOfBrith = DateOfBrith;
    }
}