/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class clsCustomersData {
   public static ArrayList<clsCustomer> Customers=new ArrayList<>();
   
      public static boolean IsIDExist(int ID)
    {
        for(clsCustomer C : Customers)
        {
        
        if(ID==C.getID())
        { 
            return true;
        }
        
        }
        return false;
    }
   
    
}
