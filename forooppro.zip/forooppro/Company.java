/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

/**
 *
 * @author ASUS
 */
public class Company extends clsCustomer{
    private String CommercialRegister;
    private double DiscountRate;

    public Company(String CommercialRegister, double DiscountRate,String CustomerName, String AdressCustomer, String PhoneCustomer) {
        super(CustomerName, AdressCustomer, PhoneCustomer);
        this.CommercialRegister = CommercialRegister;
        this.DiscountRate = DiscountRate;
    }

    public String getCommercialRegister() {
        return CommercialRegister;
    }

    public void setCommercialRegister(String CommercialRegister) {
        this.CommercialRegister = CommercialRegister;
    }

    public double getDiscountRate() {
        return DiscountRate;
    }

    public void setDiscountRate(double DiscountRate) {
        this.DiscountRate = DiscountRate;
    }
    
    
}
