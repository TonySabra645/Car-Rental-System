/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class clsCustomerRegistrationScreen extends clsScreen{
    static Scanner in=new Scanner(System.in);
    
    enum enCustomerOption
    {
        eAddNewCustomer,eFindCustomer,eShowAllCustomer,eUpdateCustmer,eMainMenue
    }
    
 private static short readCustomerOption()
{
              short option;
             do{
             System.out.println("Please Enter Number Between [1 TO 5]");
            
              option=in.nextShort(); 
             }while(option>5||option<1);
           return option;
          
}   
 
 
 private static void GoBackToCustomerRegistrationMeune()
 {
     System.out.println("Press Enter To Go Back To Customer Registration Meune... ");
     
     in.nextLine();
     in.nextLine();
     ShowCustomerRegistarationScreen();
     
 }
 
 private static void ShowAddNewCustomerScreen()
 {
     System.out.println("Add New Customer Screen Will Be Here ");
     clsAddNewCustomer.AddNewCustomerScreen();
 }
 
 private static void ShowFindCustomerScreen()
 {
     System.out.println("Find Customer Screen Will Be Here ");
     clsFindCustomersByID.ShowFindCustomerScreen();
 }
 
 private static void ShowAllCustomerScreen()
 {
     System.out.println("All Customer Screen Will Be Here");
     clsShowAllCustomerScreen.ShowAllCustomerScreen();
 }
 
 private static void ShowUpdateCustomerScreen()
 {
     System.out.println("Update Customer Will Be Here ");
     clsUpdateCustomerScreen.ShowUpdateCustomerScreen();
 }
         
 private static void PerformCustomerOption(enCustomerOption CustomerOption)
{
    switch(CustomerOption)
    {
        
        case enCustomerOption.eAddNewCustomer->
        {
            ShowAddNewCustomerScreen();
            GoBackToCustomerRegistrationMeune();
            break;
        }
            
        case enCustomerOption.eFindCustomer->
        {
            ShowFindCustomerScreen();
            GoBackToCustomerRegistrationMeune();
            break;
        }
           case enCustomerOption.eShowAllCustomer->
        {
            ShowAllCustomerScreen();
            GoBackToCustomerRegistrationMeune();
            break;
        }
        
             case enCustomerOption.eUpdateCustmer->
        {
            ShowUpdateCustomerScreen();
            GoBackToCustomerRegistrationMeune();
            break;
        }
        case enCustomerOption.eMainMenue->
        {
            
        }
        
    }
}
        
 public static void ShowCustomerRegistarationScreen()
 {
     _DrawScreenHeader("Customer Registaration : ");
     
    System.out.println("\n[1] Add New Customer Screen");
    System.out.println("[2] Find Customer Screen");
    System.out.println("[3] All Customer Screen");
    System.out.println("[4] Update Customer Screen");
    System.out.println("[5] Main Menue");
        
    PerformCustomerOption(enCustomerOption.values()[readCustomerOption()-1]);
 }

}
