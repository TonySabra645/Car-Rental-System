/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;


public class clsShowVIPCustomersScreen extends clsScreen{
public static void ShowVIPCustomersScreen()
{
    _DrawScreenHeader("VIP Customers");

    boolean Found = false;

    for(clsCustomer C : clsCustomersData.Customers)
    {
        int Count = 0;

        for(RentalContract R : clsRentalData.Countracts)
        {
            if(R.IsFinished()
               &&
               R.getCustomer().getID() ==(C.getID()))
            {
                Count++;
            }
        }

        if(Count >= 5)
        {
            Found = true;

            System.out.println("\n======================");

            System.out.println("Customer Name : "
                    + C.getCustomerName());

            System.out.println("Customer ID : "
                    + C.getID());

            System.out.println("Phone : "
                    + C.getPhoneCustomer());

            System.out.println("Finished Contracts : "
                    + Count);

            System.out.println("======================");
        }
    }

    if(!Found)
    {
        System.out.println("No VIP Customers Found.");
    }
}
    
}
