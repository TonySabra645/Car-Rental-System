/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

/**
 *
 * @author ASUS
 */
public class clsShowAllAvailableVehicleScreen extends clsScreen{

   

    public static void ShowAllAvailableVehicleScreen() {
        
        _DrawScreenHeader("Show All Avilable Vehicle Screen : ");
        
        if (clsVehicleData.Vehicles.isEmpty()) {
            System.out.println("Not Any Available Vehicle .");
            return;
        }

        for (Vehicle V : clsVehicleData.Vehicles) {

            if (V.isAvailable()) {
                clsFindVehicleByPlateNumber.PrintVehicleCard(V);
            }
            
        }
    }
}
