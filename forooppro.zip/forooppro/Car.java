/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

/**
 *
 * @author ASUS
 */
public class Car extends Vehicle{
    private String FuelType;
        private boolean HaveAirCondition;
        private short  NumberOfSeats;
        private boolean ElectricCar;
        
        
        
        
        public Car(String PlateNumber, String Brand, String Model, double DailyPrice, boolean Available, String FuelType, short NumberOfSeats, boolean HaveAirCondition,boolean ElectricCar) {
            super(PlateNumber, Brand, Model, DailyPrice, Available);
            this.FuelType=FuelType;
            this.HaveAirCondition=HaveAirCondition;
            this.NumberOfSeats=NumberOfSeats;
            this.ElectricCar=ElectricCar;
        }

    public boolean isElectricCar() {
        return ElectricCar;
    }

    public void setElectricCar(boolean ElectricCar) {
        this.ElectricCar = ElectricCar;
    }

        public String getFuelType() {
            return FuelType;
        }

        public void setFuelType(String FuelType) {
            this.FuelType = FuelType;
        }

       public boolean isHaveAirCondition() {
        return HaveAirCondition;
        }

        public void setHaveAirCondition(boolean HaveAirCondition) {
        this.HaveAirCondition = HaveAirCondition;
        }

    public short getNumberOfSeats() {
        return NumberOfSeats;
        }

    public void setNumberOfSeats(short NumberOfSeats) {
        this.NumberOfSeats = NumberOfSeats;
      }
    
}
