/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

/**
 *
 * @author ASUS
 */
public class clsScreen {
     protected static void _DrawScreenHeader(String Title)
 {
     System.out.println("\n=================================");
     System.out.println("\t"+Title+"\t");
     System.out.println("=================================");

 }
}
