/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.forooppro;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class clsFindVehicleByPlateNumber extends clsScreen{
    private static Scanner in =new Scanner(System.in);
 
 
 public  static void PrintVehicleCard(Vehicle V)
 {
     
        System.out.println("\n=======================================\n");
     System.out.println("Plate Number : "+V.getPlateNumber());
     
     System.out.println("Brand : "+V.getBrand());
     
     System.out.println("Model : "+V.getModel());
     
     System.out.println("Price : "+V.getDailyPrice());
     
     System.out.println("Is Available : "+ V.isAvailable());
     
             if(V instanceof Car)
                {              
                    System.out.println("Fuel Type : "+((Car) V).getFuelType());
                    System.out.println("Have Air Condition : "+((Car) V).isHaveAirCondition());
                    System.out.println("Number Of Seates : "+((Car) V).getNumberOfSeats());   
                       System.out.println("\n=======================================\n");
                }
                if(V instanceof Truck)
                {
           
                    System.out.println("Capacity Of Weight : "+((Truck) V).getWeightCapacity());
                    System.out.println("Refrigerated : "+((Truck) V).isRefrigerated());
                      System.out.println("\n=======================================\n");
                }
                if(V instanceof MotorCycle)
                {
               
                    System.out.println("Engine Capacity : "+((MotorCycle) V).getEngineCapacity());
                    System.out.println("Having Side Car : "+((MotorCycle) V).getHavingSidecar());
                       System.out.println("\n=======================================\n");
                }     

 }
 
 
 
   

public static Vehicle FindVehicle(String PlateNumber)
   {
     
       
       
         for(Vehicle V : clsVehicleData.Vehicles)
         {
             if(V.getPlateNumber().equalsIgnoreCase(PlateNumber))
             {
                 PrintVehicleCard(V);
                return V;
             } 
            
   }
           System.out.println("Vehicle Not Found.");
           return null;
}
   
   
   public static void ShowFindVehicleScreen()
   {
       _DrawScreenHeader("Find Vehicle Screen : ");

       
     System.out.println("Please Enter Plate Number : ");
     String PlateNumber=in.nextLine();
     Vehicle V= FindVehicle(PlateNumber);
   
   
   }
   
}
