
package com.mycompany.forooppro;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class clsContractsScreen extends clsScreen {
    
    private enum enContractsOption
    {
        eShowAllContracts,
        eShowActiveContracts,
        eShowFinishedContracts,
        eShowContractsByCustomerName,
        eShowCompanyContracts,
        eShowRentedVehicles,
        eShowVehiclesWithFines,
        eShowRentedVehiclesByPeriod,
        eShowRentedMotorCycleByPeriod,
        eShowCustomersByVehicle,
        eBack,
    }

    private static short ReadContractsOption()
    {
        short Option;

        do
        {
            System.out.println("Please Enter Number Between [1 TO 11]");
            Scanner in = new Scanner(System.in);
            Option = in.nextShort();

        } while (Option < 1 || Option > 11);

        return Option;
    }

    private static void GoBackToContractsMenu()
    {
        System.out.println("Press Enter To Go Back...");
        Scanner in = new Scanner(System.in);
        in.nextLine();

        ShowContractsScreen();
    }

    private static void ShowAllContractsScreen()
    {
        clsPrintContractScreen.ShowAllContractsScreen();
    }

    private static void ShowActiveContractsScreen()
    {
clsPrintContractScreen.ShowActiveContractScreen();
    }

    private static void ShowFinishedContractsScreen()
    {
        clsPrintContractScreen.ShowFinishedContractScreen();
    }

    private static void ShowContractsByCustomerNameScreen()
    {
        clsPrintContractScreen.ShowContractsByCustomerNameScreen();
    }

    private static void ShowCompanyContractsScreen()
    {
        clsPrintContractScreen.ShowCompanyContractsScreen();
    }

    private static void ShowRentedVehiclesScreen()
    {
        clsPrintContractScreen.ShowRentedVehicleScreen();
    }
    private static void ShowVehiclesWithFinesScreen()
    {
        clsPrintContractScreen.ShowVehiclesWithFinesScreen();
    }
    
    private static void ShowRentedVehiclesByPeriodScreen()
    {
     clsPrintContractScreen.ShowRentedVehiclesByPeriodScreen();
    }
private static void ShowRentedMotorCycleByPeriodScreen()
{

clsPrintContractScreen.ShowRentedMotorCycleByPeriodScreen();
}
private static void ShowCustomersByVehicleScreen()
{
clsPrintContractScreen.ShowCustomersByVehicleScreen();

}
    private static void PerformContractsOption(enContractsOption Option)
    {
        switch (Option)
        {
            case eShowAllContracts ->
            {
                ShowAllContractsScreen();
                GoBackToContractsMenu();
                        break;

            }

            case eShowActiveContracts ->
            {
                ShowActiveContractsScreen();
                GoBackToContractsMenu();
                       break;

            }

            case eShowFinishedContracts ->
            {
                ShowFinishedContractsScreen();
                GoBackToContractsMenu();
            break;
            }

            case eShowContractsByCustomerName ->
            {
                ShowContractsByCustomerNameScreen();
                GoBackToContractsMenu();
            break;
            }

            case eShowCompanyContracts ->
            {
                ShowCompanyContractsScreen();
                GoBackToContractsMenu();
            break;
            }

            case eShowRentedVehicles ->
            {
                ShowRentedVehiclesScreen();
                GoBackToContractsMenu();
            break;
            } 
    case eShowVehiclesWithFines ->
  {
    ShowVehiclesWithFinesScreen();
    GoBackToContractsMenu();
    break;
   }

   case eShowRentedVehiclesByPeriod ->
  {
     ShowRentedVehiclesByPeriodScreen();
     GoBackToContractsMenu();
     break;
     
  }
   case eShowRentedMotorCycleByPeriod ->
   {
ShowRentedMotorCycleByPeriodScreen();
   GoBackToContractsMenu();
   break;
   
   }
   case eShowCustomersByVehicle ->
   {
   ShowCustomersByVehicleScreen();
   GoBackToContractsMenu();
   break;
   }
   
            case eBack ->
            {
                return;
            }
        }
    }

    public static void ShowContractsScreen()
    {
        _DrawScreenHeader("Contracts Screen");

        System.out.println("[1] Show All Contracts");
        System.out.println("[2] Show Active Contracts");
        System.out.println("[3] Show Finished Contracts");
        System.out.println("[4] Show Contracts By Customer Name");
        System.out.println("[5] Show Company Contracts");
        System.out.println("[6] Show Rented Vehicles");
        System.out.println("[7] Show Vehicles With Fines");
        System.out.println("[8] Show Rented Vehicles By Period");
        System.out.println("[9] Show Rented Motor Cycle By Period");
        System.out.println("[10]Show Customer By Vehicle ");
        System.out.println("[11] Back");

        PerformContractsOption(
                enContractsOption.values()
                [ReadContractsOption() - 1]);
    }
}

